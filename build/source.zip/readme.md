# My custom app completed

## Triggers

☑️  Create Candidate
☑️  Fetch candidate

## Actions

get applications by candidate id
get company location by id


# In Vincere native app

## Triggers
* new candidate
* new cndidate added to a talent pool
* candidate unsubscribes
* candidate subscribed
* new job
* new contact added to a distribution list
* new placement added
* message send to specific group in vinny chat
* message sent to specific theme in vinny chat

## Creates
* create new contact
* unsubscribe email
* update gdpr details
* send direct message
* send group message vinnychat
* send theme message vinnychat

# General TODOS
* testing that works with Oauth
 